# Select Tabs

Quickly select multiple tabs: tabs of the same website, tabs to the left or right, parent/sibling/descendant tabs, and more.
